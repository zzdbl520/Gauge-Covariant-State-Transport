# CPDC / C5H5+ rank-2 transport — archived wavefunctions

This archive includes raw CASSCF MO/CI NPZ checkpoints, original source and frozen decision evidence, and independently generated replay reports. The original `/scr/zdb` paths are retained only for provenance; `reports/portable_evidence` uses paths relative to the release root. Replay scripts resolve these from the release root, independently of the caller working directory.

## Verified scope

- SHA256 source validation and copied-file validation: PASS.
- Reference Wilson (80 edges) and clockwise/counterclockwise histories (81 edges each): numerical replay within frozen thresholds, including edge, gauge and cyclic-start checks.
- SA3 projector comparisons: numerical replay PASS (10 history records and 5 cross-history records).
- **Not independently replayed:** CASSCF stationarity, CASCI energy reproduction, third-singlet energy gap, and other electronic-structure quality tests. The original decisions report these checks, but their PASS flags are not substitutes for independent reproduction.
- No claim is made about the number of conical intersections from rank-2 Wilson eigenphases.

## Reproduce on a machine with PySCF

Run from this directory (the replay programs import the original source modules in `code/`):

```bash
python code/cpdc_replay.py --source code --evidence reports/portable_evidence --mode all --output reports/local_wilson_replay.json
python code/cpdc_sa3_replay.py --source code --evidence reports/portable_evidence --output reports/local_sa3_replay.json
```

The replay scripts read wavefunctions and write only the requested output report. The frozen `reports/original_evidence` is not modified. `reports/portable_evidence` is generated from original JSON with only referenced wavefunction path strings relocated.

## Files

- `wavefunctions/`: NPZ with MO coefficients, CI roots, geometry and state energies.
- `code/`: original computational analysis modules and replay scripts.
- `reports/original_evidence/`: unchanged original decisions and supporting JSON.
- `reports/portable_evidence/`: locally relocated references for reproducibility.
- `reports/CPDC_full_replay.json` and `reports/CPDC_SA3_replay.json`: previously executed numerical replay outputs.
- `PROVENANCE.json`: original paths, released paths, source SHA256.
- `SHA256SUMS.txt`: SHA256 of all release files excluding this manifest.

## Portability

The `reports/portable_evidence` wavefunction paths are release-root-relative. Use explicit `--source` and `--evidence` paths to run replay from any directory. The original evidence is preserved unchanged.
