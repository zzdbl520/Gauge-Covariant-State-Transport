#!/usr/bin/env python3
import os
"""Read-only CPDC archived-wavefunction replay. Run on cu02 with PySCF installed.
Does not run CASSCF; writes only the specified JSON report.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path
import numpy as np

SOURCE = Path('/scr/zdb/CPDC_secondary_CI_ccpVTZ_lift_v1_work/CPDC_ccpVTZ_rank2_opposed_history_v1')
EVIDENCE = SOURCE / 'CPDC_rank2_final_evidence_20260920'


def load_json(p):
    return json.loads(p.read_text())


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def to_json(x):
    if isinstance(x, dict):
        return {str(k): to_json(v) for k, v in x.items()}
    if isinstance(x, (tuple, list)):
        return [to_json(v) for v in x]
    if isinstance(x, np.ndarray):
        return to_json(x.tolist())
    if isinstance(x, np.generic):
        return to_json(x.item())
    if isinstance(x, complex):
        return {'real': x.real, 'imag': x.imag}
    return x


def invariant_differences(left, right, rank2):
    # Stored JSON representation of complex invariants may vary; compare eigenphases
    # directly, and compare trace/determinant only when parsing is unambiguous.
    out = {}
    if 'eigenphases_rad' in left and 'eigenphases_rad' in right:
        out['eigenphase_set_difference_rad'] = float(rank2.phase_set_error(
            left['eigenphases_rad'], right['eigenphases_rad']))
    def parse_complex(v):
        if isinstance(v, dict) and 'real' in v and 'imag' in v:
            return complex(v['real'], v['imag'])
        if isinstance(v, (int, float, complex, str)):
            return complex(v)
        if isinstance(v, (tuple, list)) and len(v) == 2:
            return complex(v[0], v[1])
        raise ValueError('Unknown complex-number encoding')
    for name in ('trace', 'determinant'):
        try:
            out[name + '_difference'] = abs(parse_complex(left[name]) - parse_complex(right[name]))
        except (KeyError, TypeError, ValueError):
            out[name + '_difference'] = None
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--source', type=Path, default=SOURCE)
    ap.add_argument('--evidence', type=Path, default=EVIDENCE)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--memory-mb', type=int, default=16000)
    ap.add_argument('--mode', choices=['audit', 'reference', 'all'], default='audit')
    args = ap.parse_args()
    args.source = args.source.resolve()
    args.evidence = args.evidence.resolve()
    args.output = args.output.resolve()
    # Portable evidence uses release-root-relative wavefunction paths.
    os.chdir(args.evidence.parent.parent)
    history = load_json(args.evidence / 'CPDC_ccpVTZ_rank2_history_v1_decision.json')
    auth = load_json(args.evidence / 'CPDC_ccpVTZ_rank2_opposed_history_authorization_v1.json')
    ref = auth['reference_point_integrity']
    spots = auth['reference_SA3_integrity']
    points = history['point_records']
    if len(ref) != 80 or len(points) != 79:
        raise RuntimeError(f'Unexpected loop cardinalities: reference={len(ref)}, history={len(points)}')
    records = []
    def register(group, item, path_key, sha_key):
        p = Path(item[path_key]); sha = item[sha_key]
        records.append((group, p, sha))
    for item in ref: register('reference_SA2', item, 'path', 'sha256')
    for item in spots: register('reference_SA3', item, 'path', 'sha256')
    for item in points:
        for direction in ('clockwise', 'counterclockwise'):
            register(direction, item['direction_records'][direction], 'solution_file', 'solution_sha256')
    for direction in ('clockwise', 'counterclockwise'):
        register(direction + '_closure', history['closure_checks'][direction], 'solution_file', 'solution_sha256')
    failures = []
    for group, p, sha in records:
        if not p.is_file(): failures.append({'group': group, 'file': str(p), 'problem': 'missing'})
        elif digest(p) != sha: failures.append({'group': group, 'file': str(p), 'problem': 'SHA256 mismatch'})
    report = {'scope': 'CPDC rank-2 archived-wavefunction replay',
              'mode': args.mode, 'integrity': {'checked': len(records), 'failed': len(failures),
              'status': 'PASS' if not failures else 'FAIL', 'failures': failures[:20]},
              'status': 'INTEGRITY_ONLY'}
    if failures:
        args.output.write_text(json.dumps(report, indent=2) + '\n')
        raise SystemExit('Integrity failed; no numerical replay attempted')
    if args.mode != 'audit':
        sys.path.insert(0, str(args.source))
        import cpdc_lift_engine as eng
        import CPDC_ccpVTZ_rank2_opposed_history_v1 as histmod
        import CPDC_ccpVTZ_rank2_projector_v1 as rank2
        thresholds = histmod.Thresholds()
        def build(items):
            solutions = [eng.load_solution(p) for p in items]
            molecules = [eng.make_mol(np.asarray(sol['geometry_angstrom'], dtype=float),
                                      histmod.BASIS_KEY, args.memory_mb, verbose=0)
                         for sol in solutions]
            return solutions, molecules
        ref_paths = [Path(x['path']) for x in ref]
        sequence, molecules = build(ref_paths)
        reference_result = histmod.sequence_wilson(sequence, molecules, thresholds)
        frozen = history['reference_Wilson']
        report['reference'] = {
            'edges': len(reference_result['edge_records']),
            'all_edges_pass': bool(reference_result['all_edges_pass']),
            'gauge_pass': bool(reference_result['gauge_pass']),
            'cyclic_start_pass': bool(reference_result['cyclic_start_pass']),
            'minimum_pair_sigma': reference_result['minimum_pair_sigma'],
            'maximum_pair_leakage': reference_result['maximum_pair_leakage'],
            'minimum_active_sigma': reference_result['minimum_active_sigma'],
            'maximum_active_leakage': reference_result['maximum_active_leakage'],
            'wilson_invariants': to_json(reference_result['wilson_invariants']),
            'invariant_differences': invariant_differences(
                reference_result['wilson_invariants'], frozen['wilson_invariants'], rank2),
            'scalar_differences': {k: abs(float(reference_result[k]) - float(frozen[k]))
                for k in ('minimum_pair_sigma','maximum_pair_leakage',
                          'minimum_active_sigma','maximum_active_leakage')},
        }
        if args.mode == 'all':
            report['histories'] = {}
            for direction in ('clockwise', 'counterclockwise'):
                # Original history includes a separately optimized return to p000.
                # Reconstruct as p000(reference), p001..p079(history), p000(closure).
                history_paths = [ref_paths[0]] + [Path(x['direction_records'][direction]['solution_file'])
                      for x in points] + [Path(history['closure_checks'][direction]['solution_file'])]
                hseq, hmols = build(history_paths)
                computed = histmod.sequence_wilson(hseq, hmols, thresholds)
                stored = history['history_Wilson'][direction]
                report['histories'][direction] = {
                    'edges': len(computed['edge_records']),
                    'all_edges_pass': bool(computed['all_edges_pass']),
                    'gauge_pass': bool(computed['gauge_pass']),
                    'cyclic_start_pass': bool(computed['cyclic_start_pass']),
                    'minimum_pair_sigma': computed['minimum_pair_sigma'],
                    'maximum_pair_leakage': computed['maximum_pair_leakage'],
                    'minimum_active_sigma': computed['minimum_active_sigma'],
                    'maximum_active_leakage': computed['maximum_active_leakage'],
                    'wilson_invariants': to_json(computed['wilson_invariants']),
                    'invariant_differences': invariant_differences(
                        computed['wilson_invariants'], stored['wilson_invariants'], rank2),
                    'scalar_differences': {k: abs(float(computed[k]) - float(stored[k]))
                        for k in ('minimum_pair_sigma','maximum_pair_leakage',
                                  'minimum_active_sigma','maximum_active_leakage')},
                }
        report['status'] = 'NUMERICAL_REPLAY_COMPLETED_UNQUALIFIED'
        report['note'] = ('Numerical outputs require threshold comparison and validation of '
                          'history endpoint convention before claiming PASS. SA3 projector '
                          'and opposed-history SA3 qualification not replayed by this script.')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(to_json(report), indent=2, ensure_ascii=False) + '\n')
    print('Saved', args.output, '| status:', report['status'])
    print('Integrity:', report['integrity']['status'], report['integrity']['checked'])
    if 'reference' in report: print('Reference differences:', report['reference']['invariant_differences'])
    if 'histories' in report:
        for d, x in report['histories'].items(): print(d, 'edges:', x['edges'], 'differences:', x['invariant_differences'])

if __name__ == '__main__':
    main()
