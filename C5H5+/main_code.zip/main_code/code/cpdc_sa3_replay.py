#!/usr/bin/env python3
import os
"""Read-only CPDC SA3 projector replay from archived MO/CI wavefunctions.
No CASSCF optimization. Checks 10 history-SA3 and 5 cross-history records.
"""
import argparse, hashlib, json, sys
from pathlib import Path
import numpy as np

DEFAULT_SOURCE = Path('/scr/zdb/CPDC_secondary_CI_ccpVTZ_lift_v1_work/CPDC_ccpVTZ_rank2_opposed_history_v1')
DEFAULT_EVIDENCE = DEFAULT_SOURCE / 'CPDC_rank2_final_evidence_20260920'

def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()

def compare_numbers(computed, frozen):
    return {k: float(abs(computed[k] - frozen[k])) for k in computed if k in frozen and isinstance(computed[k], (int,float)) and isinstance(frozen[k], (int,float))}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--source', type=Path, default=DEFAULT_SOURCE)
    ap.add_argument('--evidence', type=Path, default=DEFAULT_EVIDENCE)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--memory-mb', type=int, default=16000)
    args = ap.parse_args()
    args.source = args.source.resolve()
    args.evidence = args.evidence.resolve()
    args.output = args.output.resolve()
    # Portable evidence uses release-root-relative wavefunction paths.
    os.chdir(args.evidence.parent.parent)
    d = json.loads((args.evidence/'CPDC_ccpVTZ_rank2_opposed_history_v1_decision.json').read_text())
    recs = d['history_SA3_records']; crosses = d['cross_history_records']; t = d['thresholds']
    if len(recs) != 10 or len(crosses) != 5:
        raise RuntimeError(f'Unexpected records: {len(recs)} history, {len(crosses)} cross')
    files = {}
    for rec in recs:
        for stem in ('seed_SA2','reference_SA3','history_SA3'):
            p = Path(rec[stem+'_file']); expected = rec[stem+'_sha256']
            if str(p) in files and files[str(p)] != expected:
                raise RuntimeError('Conflicting hashes for '+str(p))
            files[str(p)] = expected
    failures = [{'path':path,'error':'missing' if not Path(path).is_file() else 'SHA256 mismatch'} for path, expected in files.items() if not Path(path).is_file() or sha256(Path(path)) != expected]
    report = {'status':'INTEGRITY_ONLY','integrity':{'unique_files':len(files),'failed':len(failures),'failures':failures},'history_records':[],'cross_history_records':[]}
    if failures:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(report,indent=2)+'\n')
        raise SystemExit('SA3 checkpoint integrity failed')
    sys.path.insert(0,str(args.source))
    import cpdc_lift_engine as eng
    import cpdc_overlap as ov
    import CPDC_ccpVTZ_rank2_opposed_history_v1 as hist
    cache={}
    def get(path):
        if path not in cache:
            sol=eng.load_solution(Path(path))
            mol=eng.make_mol(np.asarray(sol['geometry_angstrom'],dtype=float),hist.BASIS_KEY,args.memory_mb,verbose=0)
            cache[path]=(sol,mol)
        return cache[path]
    def overlap(a,b):
        sa,ma=get(a); sb,mb=get(b)
        return ov.exact_overlap_matrix(sa,sb,ma,mb)
    def metrics(mat):
        pair=mat[:2,:2]
        sv=np.linalg.svd(pair,compute_uv=False)
        return {'pair_singular_values':sv.tolist(), 'pair_sigma_min':float(min(sv)), 'pair_leakage':float(1-np.mean(sv**2))}
    def third_weights(mat):
        return {'left_pair_to_right_third_weight':float(np.sum(abs(mat[:2,2])**2)),
                'left_third_to_right_pair_weight':float(np.sum(abs(mat[2,:2])**2))}
    def pair_pass(m, sigma_key, leakage_key):
        return bool(m['pair_sigma_min'] >= t[sigma_key] and m['pair_leakage'] <= t[leakage_key])
    by_key={}
    for rec in recs:
        seed=rec['seed_SA2_file']; reference=rec['reference_SA3_file']; history=rec['history_SA3_file']
        sr=overlap(seed,history)
        if sr.shape != (2,3): raise RuntimeError(f'SA2/SA3 shape {sr.shape}')
        sm=metrics(sr)
        sm['third_root_SA2_weight']=float(np.sum(abs(sr[:,2])**2))
        sm['pass']=pair_pass(sm,'SA2_SA3_projector_sigma_minimum','SA2_SA3_projector_leakage_maximum') and sm['third_root_SA2_weight'] <= t['SA3_cross_third_weight_maximum']
        rr=overlap(reference,history)
        if rr.shape != (3,3): raise RuntimeError(f'SA3/SA3 shape {rr.shape}')
        rm=metrics(rr); rm.update(third_weights(rr))
        rm['pass']=pair_pass(rm,'SA3_projector_sigma_minimum','SA3_projector_leakage_maximum') and max(rm['left_pair_to_right_third_weight'],rm['left_third_to_right_pair_weight']) <= t['SA3_cross_third_weight_maximum']
        entry={'direction':rec['direction'],'index':rec['index'],'angle_degrees':rec['angle_degrees'],
               'seed_SA2_to_SA3':sm,'reference_SA3_to_history_SA3':rm,
               'differences':{'seed':compare_numbers(sm,rec['seed_SA2_to_SA3']),
                              'reference':compare_numbers(rm,rec['reference_SA3_to_history_SA3'])}}
        report['history_records'].append(entry)
        key=(rec['index'],rec['direction'])
        if key in by_key: raise RuntimeError('Duplicate SA3 record '+str(key))
        by_key[key]=history
    for rec in crosses:
        i=rec['index']; a=by_key[(i,'clockwise')]; b=by_key[(i,'counterclockwise')]
        mat=overlap(a,b)
        if mat.shape != (3,3): raise RuntimeError(f'cross SA3 shape {mat.shape}')
        m=metrics(mat); m.update(third_weights(mat))
        m['pass']=pair_pass(m,'SA3_projector_sigma_minimum','SA3_projector_leakage_maximum') and max(m['left_pair_to_right_third_weight'],m['left_third_to_right_pair_weight']) <= t['SA3_cross_third_weight_maximum']
        report['cross_history_records'].append({'index':i,'angle_degrees':rec['angle_degrees'],
            'projector_metrics':m,'differences':compare_numbers(m,rec['projector_metrics'])})
    passes=[r['seed_SA2_to_SA3']['pass'] and r['reference_SA3_to_history_SA3']['pass'] for r in report['history_records']]
    passes += [r['projector_metrics']['pass'] for r in report['cross_history_records']]
    report['projector_thresholds_pass']=all(passes)
    report['status']='PROJECTOR_NUMERICAL_PASS_ENERGY_AND_QUALITY_NOT_REPLAYED' if all(passes) else 'PROJECTOR_NUMERICAL_FAIL'
    report['note']='Replays overlap/projector metrics only; energy, stationarity, CASCI, and gap qualifications remain sourced from original decision, not independently replayed.'
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print('Saved:',args.output,'status:',report['status'])
    print('SA3 files verified:',len(files),'history comparisons:',len(recs),'cross-history comparisons:',len(crosses))
    print('Maximum numerical difference:',max([v for r in report['history_records'] for dd in r['differences'].values() for v in dd.values()]+[v for r in report['cross_history_records'] for v in r['differences'].values()],default=0))
if __name__=='__main__': main()
