#!/usr/bin/env python3
"""Read-only BeH2 original-wavefunction fidelity audit using PySCF fci.addons.overlap.

Do NOT use the older determinant-minor audit as a benchmark until its discrepancy
with PySCF has been resolved. Does not optimize wavefunctions or overwrite inputs.
"""
import argparse, csv, itertools, json, time, sys
from pathlib import Path
import numpy as np
from pyscf import fci, gto
import pyscf

BRANCHES = {'SA3_unique_up':'SA3/unique_up', 'SA3_upper_down':'SA3/upper_down',
            'SA4_upper_up':'SA4/upper_up', 'SA4_upper_down':'SA4/upper_down'}
PAIRS = [('SA3_unique_up','SA3_upper_down'), ('SA4_upper_up','SA4_upper_down'),
         ('SA3_unique_up','SA4_upper_up'), ('SA3_upper_down','SA4_upper_down')]

def read(root, branch, lam):
    fn=root/BRANCHES[branch]/('lambda_'+f'{lam:.8f}'.replace('.','p')+'.npz')
    with np.load(fn,allow_pickle=False) as z:
        d={k:np.array(z[k]) for k in z.files}
    for key in ('lambda_bohr','atom_coords_bohr','atom_charges','ao_overlap','mo_coeff',
                'ci_states','ncore','ncas','nelecas','e_average','energies'):
        if key not in d: raise ValueError(f'{fn}: missing {key}')
    d['file']=str(fn);d['ncore']=int(d['ncore']);d['ncas']=int(d['ncas'])
    d['nelecas']=tuple(map(int,np.ravel(d['nelecas'])))
    d['ci_states']=np.asarray(d['ci_states'])
    if d['ncore']!=0: raise ValueError(f'{fn}: ncore != 0, inactive overlap not implemented')
    if abs(float(d['lambda_bohr'])-lam)>1e-8:raise ValueError(f'{fn}: lambda mismatch')
    return d

def molecule(d,basis):
    mol=gto.Mole()
    mol.atom=[(int(z),tuple(map(float,r))) for z,r in zip(d['atom_charges'],d['atom_coords_bohr'])]
    mol.unit='Bohr';mol.basis=basis;mol.charge=0;mol.spin=0;mol.verbose=0;mol.build()
    if mol.nao_nr()!=d['mo_coeff'].shape[0]:raise ValueError('AO count mismatch; verify basis and atom ordering')
    local=mol.intor('int1e_ovlp')
    err=float(np.max(np.abs(local-d['ao_overlap'])))
    if err>1e-8:raise ValueError(f'Checkpoint AO overlap disagrees with reconstructed AO: {err}')
    return mol

def ao_cross(a,b,basis,cache):
    same=(np.array_equal(a['atom_charges'],b['atom_charges']) and
          np.max(np.abs(a['atom_coords_bohr']-b['atom_coords_bohr']))<1e-12)
    if same:
        if np.max(np.abs(a['ao_overlap']-b['ao_overlap']))>1e-8:raise ValueError('AO overlap mismatch at same geometry')
        return a['ao_overlap']
    for d in (a,b):
        if d['file'] not in cache:cache[d['file']]=molecule(d,basis)
    return gto.intor_cross('int1e_ovlp',cache[a['file']],cache[b['file']])

def overlap(a,b,s_ao):
    if a['ncas']!=b['ncas'] or a['nelecas']!=b['nelecas']:
        raise ValueError('Incompatible active spaces')
    na=a['ncas'];ea=a['nelecas']
    ca=a['mo_coeff'][:,a['ncore']:a['ncore']+na]
    cb=b['mo_coeff'][:,b['ncore']:b['ncore']+na]
    s_act=ca.conj().T@s_ao@cb
    O=np.empty((len(a['ci_states']),len(b['ci_states'])),complex)
    for i,ci_a in enumerate(a['ci_states']):
        for j,ci_b in enumerate(b['ci_states']):
            O[i,j]=fci.addons.overlap(ci_a,ci_b,na,ea,s=s_act)
    return O, s_act

def diag(O,dim=None):
    s=np.linalg.svd(O,compute_uv=False)
    m=dim if dim is not None else min(O.shape)
    if len(s)!=m:raise ValueError('Dimension mismatch')
    if np.max(s)>1+1e-7:raise ValueError('Singular value > 1: invalid overlap or normalization')
    return {'singular_values':s.tolist(),'sigma_min':float(s[-1]),
            'mean_leakage':float(1-np.sum(s*s)/m),
            'worst_leakage':float(1-s[-1]**2)}

def entry(kind,lam_a,lam_b,ba,bb,a,b,O,s_act):
    e={'kind':kind,'lambda_a':lam_a,'lambda_b':lam_b,'branch_a':ba,'branch_b':bb,
       'delta_e_eh':float(b['e_average']-a['e_average']) if lam_a==lam_b else None,
       'active_singular_values':np.linalg.svd(s_act,compute_uv=False).tolist(),
       'overlap_real':O.real.tolist(),'overlap_imag':O.imag.tolist(),**diag(O)}
    return e

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',type=Path,default=Path('/mnt/BeH2/BeH2_B0/BeH2_B3R/BeH2_B3R_work/solutions/A1'))
    ap.add_argument('--out',type=Path,default=Path('BeH2_original_PySCF_fidelity_v3'))
    ap.add_argument('--basis',default='cc-pVTZ')
    ap.add_argument('--start',type=float,default=2.52170)
    ap.add_argument('--count',type=int,default=6)
    ap.add_argument('--step',type=float,default=0.00005)
    args=ap.parse_args()
    t0=time.monotonic()
    def progress(msg):
        print(f'[+{time.monotonic()-t0:.1f}s] {msg}', flush=True)
    progress(f'START Python={sys.version.split()[0]} PySCF={pyscf.__version__}')
    progress(f'ROOT={args.root.resolve()} OUT={args.out.resolve()}')
    progress(f'COUNT={args.count} START={args.start} STEP={args.step}')
    if args.out.exists() and any(args.out.iterdir()):raise SystemExit('Output directory must be new/empty; refusing overwrite')
    args.out.mkdir(parents=True,exist_ok=True)
    ls=[round(args.start+i*args.step,8) for i in range(args.count)]
    data={}
    for br in BRANCHES:
        for lam in ls:
            progress(f'LOAD {br} lambda={lam:.8f}')
            data[br,lam]=read(args.root,br,lam)
    progress(f'LOADED {len(data)} checkpoints')
    cache={};results=[]; subsets=[];checks=[]
    for (br,lam),d in data.items():
        progress(f'CHECK {br} lambda={lam:.8f}')
        mo=d['mo_coeff'];err=float(np.max(np.abs(mo.T@d['ao_overlap']@mo-np.eye(mo.shape[1]))))
        norms=[float(np.linalg.norm(ci)) for ci in d['ci_states']]
        if err>1e-7 or max(abs(v-1) for v in norms)>1e-6:raise ValueError(f'Bad MO/CI normalization: {d["file"]}')
        checks.append({'branch':br,'lambda':lam,'orth_error':err,'ci_norms':norms,
                       'norm_gorb':float(d['norm_gorb']) if 'norm_gorb' in d else None})
    progress('CHECKS complete; starting same-geometry overlaps')
    for lam in ls:
        for ba,bb in PAIRS:
            progress(f'COMPUTE SAME {lam:.8f} {ba}/{bb}')
            a,b=data[ba,lam],data[bb,lam]
            O,s=overlap(a,b,ao_cross(a,b,args.basis,cache))
            e=entry('same',lam,lam,ba,bb,a,b,O,s);results.append(e)
            print(f'SAME {lam:.8f} {ba}/{bb}: sigma={e["sigma_min"]:.9f} leakage={e["mean_leakage"]:.9f}',flush=True)
            if a['ci_states'].shape[0]==3 and b['ci_states'].shape[0]==4:
                for subset in itertools.combinations(range(4),3):
                    z=diag(O[:,subset]);subsets.append({'lambda':lam,'branch_a':ba,'branch_b':bb,
                           'subset':list(subset),**z})
    for br in BRANCHES:
        for la,lb in zip(ls[:-1],ls[1:]):
            progress(f'COMPUTE EDGE {br} {la:.8f}->{lb:.8f}')
            a,b=data[br,la],data[br,lb]
            O,s=overlap(a,b,ao_cross(a,b,args.basis,cache))
            e=entry('edge',la,lb,br,br,a,b,O,s);results.append(e)
            # Independent reversal check using reverse AO overlap
            R,_=overlap(b,a,ao_cross(a,b,args.basis,cache).conj().T)
            rev=float(np.max(np.abs(O-R.conj().T)))
            e['reverse_overlap_error']=rev
            if rev>1e-8:raise ValueError(f'Reverse overlap failed: {br} {la} {lb}: {rev}')
            print(f'EDGE {br} {la:.8f}->{lb:.8f}: sigma={e["sigma_min"]:.9f} leakage={e["mean_leakage"]:.9f}',flush=True)
    # Check known original B3R result, not a substitute for an independent test
    target=next(e for e in results if e['kind']=='same' and e['branch_a']=='SA3_unique_up'
                and e['branch_b']=='SA3_upper_down' and abs(e['lambda_a']-2.52195)<1e-8) if 2.52195 in ls else None
    if target:
        ref=0.9178266379157551
        if abs(target['sigma_min']-ref)>1e-6:raise ValueError(f'Original PySCF benchmark mismatch: {target["sigma_min"]} vs {ref}')
    payload={'pyscf_version':pyscf.__version__,'root':str(args.root),'lambdas':ls,
             'method':'pyscf.fci.addons.overlap with nonorthogonal active MO overlap',
             'notes':['Full 3x4 SA3-SA4 rectangular overlap and every 3-of-4 subset are distinct comparisons.',
                      'Cross-geometry AO overlaps rebuilt via gto.intor_cross.',
                      'Do not equate these metrics with B3R mixed plaquette eta without inspecting its formula.'],
             'checks':checks,'results':results,'sa4_subsets':subsets}
    (args.out/'report.json').write_text(json.dumps(payload,indent=2)+'\n')
    with (args.out/'summary.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['kind','lambda_a','lambda_b','branch_a','branch_b','delta_e_eh','sigma_min','mean_leakage','worst_leakage','singular_values','reverse_overlap_error'])
        for e in results:w.writerow([e.get(k) for k in ('kind','lambda_a','lambda_b','branch_a','branch_b','delta_e_eh','sigma_min','mean_leakage','worst_leakage','singular_values','reverse_overlap_error')])
    with (args.out/'sa4_subsets.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['lambda','branch_a','branch_b','subset','sigma_min','mean_leakage','singular_values'])
        for e in subsets:w.writerow([e.get(k) for k in ('lambda','branch_a','branch_b','subset','sigma_min','mean_leakage','singular_values')])
    progress('FINISHED calculations')
    print('SAVED',args.out/'report.json',args.out/'summary.csv',args.out/'sa4_subsets.csv')
if __name__=='__main__':main()
