# BeH2 reproducibility data

Original A1 SA3/SA4-CASSCF(6e,6o)/cc-pVTZ wavefunctions at six geometries (lambda 2.52170 through 2.52195 bohr). Original gradient convergence tolerance 3e-6. Fidelity audit: PySCF 2.13.1, NumPy 2.3.5.

Run from the original work directory after extracting:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -u BeH2_original_PySCF_fidelity_v5_complete.py --root solutions/A1 --out BeH2_v5_replay --start 2.52170 --count 6
```

The archive includes original checkpoints, original B0/B3R analysis scripts and outputs, and the PySCF-v5 replay script and outputs. For publication, extract the `BeH2/` folder into the repository root; do not replace the existing root-level LiH files. Verify with `sha256sum -c BeH2/SHA256SUMS.txt` from the repository root. The previous custom determinant-minor implementation is excluded because it disagrees with the independently validated PySCF overlap.
