
    
  
#!/usr/bin/env python3
"""Create a non-destructive 34-checkpoint O3 Gate4B Newton sensitivity overlay.

The two Newton outputs are NOT converged. Never use this overlay as a
production/release dataset; it is for sensitivity analysis only.
"""
import argparse, hashlib, json, shutil
from pathlib import Path
import numpy as np

NAMES = ('dr_minus_h_0p002500_SA2', 'dr_plus_h_0p002500_SA2')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024), b''): h.update(block)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--original',type=Path,default=Path('/mnt/O3/O3_gate4B/O3_gate4B_work_v5'))
    ap.add_argument('--newton',type=Path,default=Path('/mnt/O3/O3_gate4B/O3_gate4B_newton_test'))
    ap.add_argument('--output',type=Path,default=Path('/mnt/O3/O3_gate4B/O3_gate4B_newton_overlay'))
    args=ap.parse_args()
    orig=args.original.resolve(); new=args.newton.resolve(); out=args.output.resolve()
    if out.exists(): raise SystemExit(f'Output already exists; refusing overwrite: {out}')
    if out==orig or out==new: raise SystemExit('Output must be separate')
    sources=sorted((orig/'wavefunctions').glob('*.npz'))
    if len(sources)!=34: raise SystemExit(f'Expected 34 original wavefunctions, found {len(sources)}')
    checks=[]
    for name in NAMES:
        a=orig/'wavefunctions'/f'{name}.npz'; b=new/f'{name}_newton.npz'
        if not a.is_file() or not b.is_file(): raise SystemExit(f'Missing {a} or {b}')
        with np.load(a,allow_pickle=False) as x, np.load(b,allow_pickle=False) as y:
            if bool(y['newton_converged'].item()): raise SystemExit('This script is intended for unconverged diagnostic runs only')
            if str(y['source_sha256'].item())!=sha(a): raise SystemExit(f'Source SHA mismatch: {name}')
            for key in ('basis','protocol','tag','ncas','nelecas','ncore','r1','r2','theta','point_group'):
                if not np.array_equal(x[key],y[key]): raise SystemExit(f'Mismatch {name} {key}')
            for key in ('mo_coeff','ci_vectors','state_energies'):
                if x[key].shape!=y[key].shape: raise SystemExit(f'Shape mismatch {name} {key}')
            checks.append((name,a,b))
    (out/'wavefunctions').mkdir(parents=True)
    for p in sources:
        shutil.copy2(p,out/'wavefunctions'/p.name)
    manifest=[]
    for name,a,b in checks:
        with np.load(a,allow_pickle=False) as x, np.load(b,allow_pickle=False) as y:
            fields={k:x[k].copy() for k in x.files}
            for k in ('mo_coeff','ci_vectors','state_energies','ncore'):
                fields[k]=y[k].copy()
            fields['optimizer']=np.array('newton_direct_from_original_mo_ci')
            fields['convergence_mode']=np.array('newton_unconverged_diagnostic')
            fields['final_orbital_gradient']=np.array(float('nan'))
            fields['final_density_change']=np.array(float('nan'))
            fields['final_max_orbital_rotation']=np.array(float('nan'))
            fields['initial_orbital_seed']=np.array('original Gate4B MO/CI; Newton diagnostic')
            fields['mc_conv_tol_grad']=y['requested_grad_tol'].copy()
            fields['newton_converged']=y['newton_converged'].copy()
            fields['newton_source_sha256']=y['source_sha256'].copy()
            fields['newton_max_cycle']=y['newton_max_cycle'].copy()
            fields['newton_E_SA_Eh']=y['E_SA_Eh'].copy()
            # Original natural occupations are stale after orbital/CI replacement.
            fields.pop('natural_occupations',None)
            target=out/'wavefunctions'/f'{name}.npz'
            np.savez_compressed(target,**fields)
            manifest.append(dict(name=name,source_sha256=sha(a),newton_sha256=sha(b),overlay_sha256=sha(target),newton_converged=False))
    (out/'OVERLAY_NOT_CONVERGED.txt').write_text('DIAGNOSTIC ONLY. Two SA2 Newton checkpoints did not meet 1e-6 gradient threshold. Do not publish as fully converged. Original 34 wavefunctions preserved elsewhere. Original natural occupations and final gradient values are deliberately omitted/NaN for replaced checkpoints.\n')
    (out/'overlay_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(f'Created {out}; 34 wavefunctions, 2 Newton diagnostic replacements')
    print('Original data unchanged. NOT CERTIFIED CONVERGED.')
if __name__=='__main__': main()


