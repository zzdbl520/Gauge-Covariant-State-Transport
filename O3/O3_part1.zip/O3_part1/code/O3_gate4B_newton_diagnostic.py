
    
  
#!/usr/bin/env python3
"""Read-only Gate4B SA2 Newton sensitivity test on two original checkpoints.

Requires original O3_gate4B_run.py in --source-dir, PySCF and NumPy.
Never changes source checkpoints. Saves independent NPZ and logs.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import traceback
import numpy as np

NAMES = ('dr_minus_h_0p002500_SA2', 'dr_plus_h_0p002500_SA2')

def sha256(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-dir',type=Path,default=Path('/mnt/O3/O3_gate4B'))
    p.add_argument('--original-workdir',type=Path,default=Path('/mnt/O3/O3_gate4B/O3_gate4B_work_v5'))
    p.add_argument('--output-dir',type=Path,default=Path('/mnt/O3/O3_gate4B/O3_gate4B_newton_test'))
    p.add_argument('--grad-tol',type=float,default=1e-6)
    p.add_argument('--energy-tol',type=float,default=1e-10)
    p.add_argument('--max-cycle',type=int,default=30)
    p.add_argument('--threads',type=int,default=16)
    p.add_argument('--memory-mb',type=int,default=120000)
    p.add_argument('--verbose',type=int,default=4)
    args=p.parse_args()
    args.source_dir=args.source_dir.resolve()
    args.original_workdir=args.original_workdir.resolve()
    args.output_dir=args.output_dir.resolve()
    if args.output_dir==args.original_workdir or args.original_workdir in args.output_dir.parents:
        p.error('Output directory must be outside the original workdir')
    if args.max_cycle<1 or args.threads<1 or args.grad_tol<=0: p.error('Invalid controls')
    script=args.source_dir/'O3_gate4B_run.py'
    if not script.is_file(): p.error(f'Missing original script: {script}')
    spec=importlib.util.spec_from_file_location('O3_gate4B_run_original',script)
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    from pyscf import fci,gto,lib,mcscf,scf
    lib.num_threads(args.threads)
    args.output_dir.mkdir(parents=True,exist_ok=True)
    results=[]
    for name in NAMES:
        src=args.original_workdir/'wavefunctions'/f'{name}.npz'
        if not src.is_file(): raise FileNotFoundError(src)
        dst=args.output_dir/f'{name}_newton.npz'
        logfile=args.output_dir/f'{name}_newton.log'
        if dst.exists() or logfile.exists(): raise FileExistsError(f'Refusing to overwrite {dst} or {logfile}')
        with np.load(src,allow_pickle=False) as d:
            original={k:d[k].copy() for k in d.files}
        def val(k): return original[k].item()
        assert str(val('protocol'))=='SA2' and int(val('nroots'))==2
        assert int(val('ncas'))==12 and int(val('nelecas'))==18
        assert str(val('point_group'))=='Cs'
        basis=str(val('basis'))
        mol=module.build_mol_values(float(val('r1')),float(val('r2')),float(val('theta')),
            basis,args.memory_mb,args.verbose,gto,logfile)
        try:
            # RHF is used only as the integral/mean-field provider. Newton starts
            # from the saved original CASSCF MO/CI, not from a new CASSCF run.
            mf=scf.RHF(mol)
            mf.conv_tol=1e-12
            mf.max_cycle=150
            mf.kernel()
            if not mf.converged: raise RuntimeError('RHF did not converge')
            mc=mcscf.CASSCF(mf,12,18)
            mc.max_memory=args.memory_mb
            mc.conv_tol=args.energy_tol
            mc.conv_tol_grad=args.grad_tol
            solver=fci.direct_spin0_symm.FCI(mol)
            solver.wfnsym=module.odd_irrep(mol)
            solver.nroots=2
            solver.conv_tol=1e-12
            solver.max_cycle=300
            mc.fcisolver=solver
            mc.state_average_([0.5,0.5])
            mo=original['mo_coeff']
            ci=[np.array(x,copy=True) for x in original['ci_vectors']]
            # Verify MO orthonormality in the original molecular AO metric.
            S=mol.intor('int1e_ovlp')
            orth_err=float(np.linalg.norm(mo.conj().T@S@mo-np.eye(mo.shape[1])))
            if orth_err>1e-6: raise RuntimeError(f'Original MO orthonormality error {orth_err}')
            print(f'\nORIGINAL CHECKPOINT: {src}\nSHA256: {sha256(src)}\n'
                  f'Initial MO orthonormality error: {orth_err:.3e}',file=mol.stdout,flush=True)
            newton=mc.newton()
            newton.max_cycle_macro=args.max_cycle
            newton.conv_tol=args.energy_tol
            newton.conv_tol_grad=args.grad_tol
            newton.kernel(mo,ci)
            converged=bool(newton.converged)
            print(f'NEWTON_CONVERGED={converged}',file=mol.stdout,flush=True)
            # they are NOT certified converged checkpoints.
            new_ci=module.ci_list(newton.ci)
            if len(new_ci)!=2: raise RuntimeError('Newton returned unexpected CI roots')
            new_energies=np.asarray(module.state_energies(newton,2,np))
            tmp=dst.with_name(dst.name+'.tmp.npz')
            np.savez_compressed(tmp,
                source_checkpoint=str(src),source_sha256=sha256(src),
                source_optimizer=str(val('optimizer')),
                protocol='SA2',tag=str(val('tag')),direction=str(val('direction')),
                sign=int(val('sign')),h=float(val('h')),
                r1=float(val('r1')),r2=float(val('r2')),theta=float(val('theta')),
                basis=basis,point_group='Cs',ncas=12,nelecas=18,
                ncore=int(newton.ncore) if isinstance(newton.ncore,int) else int(np.sum(newton.ncore)),
                optimizer='newton_direct_from_original_mo_ci',
                newton_converged=converged,
                requested_grad_tol=args.grad_tol,
                requested_energy_tol=args.energy_tol,
                newton_max_cycle=args.max_cycle,
                mo_coeff=np.asarray(newton.mo_coeff),
                ci_vectors=np.stack(new_ci),state_energies=new_energies,
                E_SA_Eh=float(newton.e_tot),
                original_mo_orthonormality_error=orth_err,
                original_final_orbital_gradient=float(val('final_orbital_gradient')),
                original_state_energies=original['state_energies'])
            tmp.replace(dst)
            record=dict(name=name,source_sha256=sha256(src),newton_converged=converged,
                original_final_orbital_gradient=float(val('final_orbital_gradient')),
                requested_grad_tol=args.grad_tol,
                original_state_energies=original['state_energies'].tolist(),
                newton_state_energies=new_energies.tolist(),
                newton_E_SA_Eh=float(newton.e_tot),
                result=str(dst),log=str(logfile),
                note='Read actual final Newton gradient from log; not inferred from convergence flag')
            results.append(record)
            print(json.dumps(record,indent=2),flush=True)
        finally:
            module.close_log(mol)
    summary=args.output_dir/'newton_diagnostic_summary.json'
    if summary.exists(): raise FileExistsError(summary)
    summary.write_text(json.dumps(results,indent=2)+'\n')
    print('FINISHED. Original checkpoints untouched. Summary:',summary,flush=True)

if __name__=='__main__':
    main()
