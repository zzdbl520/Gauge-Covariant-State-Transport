# O3 Gate 4B — Reproducibility archive

This archive preserves the original O3 Gate 4B calculations and a separate Newton-polishing sensitivity test. It does not claim that the two Newton points reached the requested gradient tolerance.

## Calculation definition
- O3, Cs symmetry, cc-pVTZ, CAS(18e,12o), equally weighted SA2 and SA3.
- 17 geometries per protocol; **34 original MO/CI checkpoints**.
- Two original SA2 antisymmetric-stretch points at h = +/-0.0025 Angstrom were accepted by the predefined `stationary_floor` rule, **not** standard PySCF gradient convergence. Original residual orbital gradients: 5.08e-5 and 5.09e-5.
- Independent Newton polishing began from the original MO/CI and requested a 1e-6 gradient threshold; **both runs report newton_converged=false**. Do not label the overlay as fully converged.

## Sensitivity comparison (h=0.0025 Angstrom)
- Original C_max: 2.005249975735e-05
- Newton-overlay C_max: 2.005461536062e-05
- Relative C_max change: 0.010550%
- Original stretch maximum fit exponent: 0.751260649
- Newton-overlay stretch maximum fit exponent: 0.751245429
- Original eta_edge_min: 9.995377842418e-01
- Newton-overlay eta_edge_min: 9.995377504388e-01
- Original lambda_nuclear_max: 6.157311297792e-04
- Newton-overlay lambda_nuclear_max: 6.157335558175e-04

The observed finite-grid nonclosure is insensitive to the tested orbital-optimization correction. This does not establish a strict asymptotic exponent or certify the entire grid at 1e-6.

## Layout
- `O3/original/`: original Gate4B checkpoints, logs, and analysis outputs.
- `O3/newton_test/`: two direct-from-original-MO/CI Newton checkpoints, logs, and summary.
- `O3/newton_overlay/`: 34-checkpoint diagnostic overlay (32 original + 2 Newton) and analysis outputs.
- `O3/code/`: original run/analyze scripts and diagnostic helper scripts when present.
- `O3/manifest.csv`: path, size, and SHA256 for every archived payload file.
- `O3/SHA256SUMS.txt`: SHA256 for all payload files.

Note: the overlay's source logs may be absent or correspond to the original one-step run; do not infer the Newton residual gradient from the overlay's aggregate convergence metadata. Inspect `newton_test/` logs for the Newton gradient and convergence status.

The original data are preserved unmodified. All source files were read only when creating this ZIP.
