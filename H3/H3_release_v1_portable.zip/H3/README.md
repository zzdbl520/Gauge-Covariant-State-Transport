# H3 closed-ring topology control: original reproducibility archive

Companion data for the H3 example of *Gauge-Covariant Closed-Loop Transport of Multireference State Manifolds* (JCTC manuscript ct-2026-02017u).

## Original protocol

Neutral doublet H3; ROHF initial guess; equal-weight SA2 and SA3 CASSCF(3e,3o)/cc-pVTZ; no doubly occupied inactive core (ncore=0). Distortion radius 0.010 angstrom, reference circumradius 0.90 angstrom. Nuclear ring sampling: 36, 72, 144 points (10, 5, 2.5 degrees). Source NPZ coordinates are in angstrom.

## Files

- `H3_ring_N/corners/`: 2N original MO/CI NPZ wavefunctions per ring (SA2 and SA3). Optional ROHF `.chk` files and logs are included if present.
- `H3_ring_N/ring_matrices.npz`, `run_manifest.json`, `ring_summary.json`: original archived analyses.
- `code/`: original calculation and analysis scripts.
- `SHA256SUMS.txt`: checksum of every included original data/code file.
- `manifest.csv`: file paths, sizes, SHA256.

## Interpretation and qualification

The original 36-point summary is `REVIEW`; 72- and 144-point summaries are `PILOT_PASS`. Preserve those original labels. Both selected adiabatic states have Berry phase pi under SA2 and SA3 for all three grids; SA3 has six exchange-preferred edges at each resolution. The original maximum mixed-model edge leakage is 0.0148129831 (36), 0.0147788310 (72), and 0.0147622095 (144), all greater than 0.01. The pilot status does not certify a stricter 0.01 fidelity gate, nor does a Berry phase of pi certify root-by-root continuity.

## Reproducibility

Inspect the original scripts' CLI options and `run_manifest.json` before rerunning analysis; this archive preserves original outputs rather than claiming independent recomputation. Original summaries report Python 3.10.18, NumPy 2.2.6 and PySCF 2.10.0. A later PySCF version should be independently cross-validated before changing the reported reference numbers.

Verify checksums after extracting the `H3/` directory: `cd H3 && sha256sum -c SHA256SUMS.txt`.

No license is implied unless supplied by the authors.
